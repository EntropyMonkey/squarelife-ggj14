﻿using UnityEngine;
using System.Collections;

public class Age : MonoBehaviour {
    public float age = 0;
}
